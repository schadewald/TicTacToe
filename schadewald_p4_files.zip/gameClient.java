import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

public class gameClient
{
    public static void main(String[] args) throws IOException
    {
        final int PORT = 8888;
        Socket s = new Socket("localhost", PORT);
        InputStream inStream = s.getInputStream();
        OutputStream outStream = s.getOutputStream();
        Scanner in = new Scanner(inStream);
        PrintWriter out = new PrintWriter(outStream);
        System.out.println("Testing gameClient.");
//        String command = "DEPOSIT 3 1000\n";
//        System.out.print("Sending: " + command);
//        out.print(command);
//        out.flush();
//        String response = in.nextLine();
//        System.out.println("Receiving: " + response);
        s.close();
    }
}